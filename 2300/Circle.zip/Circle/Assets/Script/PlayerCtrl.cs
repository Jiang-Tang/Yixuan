﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCtrl : MonoBehaviour{
    public Animator m_Anim;

    void Update()
    {
        if (Input.GetKey(KeyCode.RightArrow))
        {
            transform.rotation = Quaternion.Euler(0f, 0f, 0f);
            m_Anim.SetBool("stand to run", true);
        }else if (Input.GetKeyUp(KeyCode.RightArrow))
        {
            m_Anim.SetBool("stand to run", false);
        }
        else if (Input.GetKeyUp(KeyCode.LeftArrow))
        {
            transform.rotation = Quaternion.Euler(0f, 180f, 0f);
            m_Anim.SetBool("stand to run", false);
        }
        else if (Input.GetKeyUp(KeyCode.LeftArrow))
        {
            m_Anim.SetBool("stand to run", false);
        }
    }
}
